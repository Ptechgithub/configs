Note
====
Theme Information
Traveller - is a simple, modern, flat and clean Responsive Bootstrap Theme especially for travel company. It comes with package, Price table, Gallery, About us section and Carousel banner. The site has been designed for travel agency, tour operator, travel blog and well suited to any business.Highly Responsive website give compatibility to all the latest devices. It�s prefect to browse your website on any devices. Userd all latest technology HTML5 CSS3, jQuery and bootstrap.

Key features
Twitter Bootstrap 3.1.1
Fully Responsive
Price Pack
Gallery
FontAwesome Icons
Contact Form

Responsive, Bootstrap Mobile First Web Template
 
Author URI: http://webthemez.com/

License: Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).


Credits
=======
Framework  http://getbootstrap.com
Images	Unsplash (http://unsplash.com - CC0 licensed) 
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/) 

