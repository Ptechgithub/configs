Atlanta : Free business/corporate Bootstrap responsive template
-------
Atlanta is a free, responsive, modern-looking business template based on Bootstrap HTML/CSS framework. 

Features :
--------
=> Easy to use, Heigh quality coded HTML5 and CSS3.
=> Multi device compatibility
=> Responsive design with bootstrap
=> premium quality template

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/
